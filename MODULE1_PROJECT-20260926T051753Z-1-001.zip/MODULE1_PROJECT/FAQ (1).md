# Frequently Asked Questions (FAQ)

**Q1. Which version of Python should I install?**
Always install the latest stable Python 3.x release from python.org. Python 2 reached end-of-life in 2020 and should not be used for new projects.

**Q2. Do I need to install pip separately?**
No. Since Python 3.4, `pip` is included automatically with the standard installer. If it's missing, run `python -m ensurepip --upgrade`.

**Q3. What's the difference between `python` and `python3` commands?**
On Windows, `python` usually refers to Python 3 by default. On macOS and Linux, `python3` is commonly used because `python` may not exist or may point to an older Python 2 installation.

**Q4. Can I have multiple versions of Python installed at once?**
Yes. Tools like `pyenv` (macOS/Linux) or the Python Launcher (`py`, on Windows) let you manage and switch between multiple versions.

**Q5. Do I need administrator/root access to install Python?**
It's recommended, especially on Windows, so the installer can add Python to the system PATH. On Linux, `sudo` is required for system-wide installation via a package manager.

**Q6. How do I uninstall Python?**
- **Windows:** Go to Settings → Apps → find Python → Uninstall.
- **macOS:** Delete the Python framework from `/Library/Frameworks/Python.framework`, or use Homebrew: `brew uninstall python`.
- **Linux:** Use your package manager, e.g. `sudo apt remove python3`.

**Q7. What is a virtual environment, and do I need one?**
A virtual environment is an isolated Python environment for a specific project, preventing conflicts between package versions. It's recommended for most development work. Create one with:
```bash
python -m venv myenv
```

**Q8. Where can I get help if I'm stuck?**
Refer to the official Python documentation at [docs.python.org](https://docs.python.org/), or the `Troubleshooting` section in `Installation.md`.
