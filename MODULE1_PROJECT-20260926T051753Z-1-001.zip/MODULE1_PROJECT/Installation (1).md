# Installation Guide

This guide covers installing Python on **Windows**, **macOS**, and **Linux**.

---

## 1. Installation Steps

### Windows

1. Go to [python.org/downloads](https://www.python.org/downloads/) and click **Download Python** (the latest stable version).
2. Run the downloaded `.exe` installer.
3. On the first setup screen, **check the box "Add Python to PATH"** — this step is easy to miss but important.
4. Click **Install Now** and wait for the installation to complete.
5. Click **Close** once finished.

### macOS

1. Go to [python.org/downloads](https://www.python.org/downloads/) and download the macOS installer (`.pkg` file).
2. Open the downloaded file and follow the installer prompts (Continue → Agree → Install).
3. Enter your Mac password if prompted, and wait for installation to finish.
4. Alternatively, if you use [Homebrew](https://brew.sh/), you can install Python by running:
   ```bash
   brew install python
   ```

### Linux (Debian/Ubuntu-based)

Most Linux distributions come with Python pre-installed. To install or update it manually:

```bash
sudo apt update
sudo apt install python3 python3-pip -y
```

For Fedora-based systems:

```bash
sudo dnf install python3 python3-pip -y
```

---

## 2. Verification Steps

After installation, confirm that Python was installed correctly.

1. Open a terminal (macOS/Linux) or Command Prompt / PowerShell (Windows).
2. Run the following command:
   ```bash
   python --version
   ```
   On some macOS/Linux systems, use `python3 --version` instead, since `python` may point to Python 2 or not exist at all.
3. You should see output similar to:
   ```
   Python 3.12.4
   ```
4. Verify that the package manager `pip` is also installed:
   ```bash
   pip --version
   ```
5. (Optional) Open the Python interactive shell to confirm it runs correctly:
   ```bash
   python
   >>> print("Hello, Python!")
   ```
   Type `exit()` to leave the shell.

---

## 3. Troubleshooting

| Problem | Likely Cause | Solution |
|---|---|---|
| `'python' is not recognized as an internal or external command` (Windows) | Python wasn't added to PATH during installation | Reinstall Python and check "Add Python to PATH", or manually add the Python install folder to your system PATH |
| `command not found: python` (macOS/Linux) | System uses `python3` instead of `python` | Use `python3` and `pip3` instead, or create an alias |
| `pip` not recognized | Pip wasn't installed or PATH issue | Run `python -m ensurepip --upgrade`, or reinstall Python with pip included |
| Installer fails to run (Windows) | Insufficient permissions | Right-click the installer and choose **Run as administrator** |
| Old Python version shown after update | Multiple Python versions installed | Check installed versions with `where python` (Windows) or `which -a python3` (macOS/Linux) and update PATH order |
| Permission denied errors (Linux) | Missing sudo privileges | Prefix installation commands with `sudo` |
| SSL / certificate errors when using pip | Outdated pip or missing certificates | Run `python -m pip install --upgrade pip` and ensure system date/time is correct |

If a problem isn't listed here, search the exact error message along with "Python installation" — most issues have been documented by the Python community.

---

## Conclusion

You have now learned how to install Python on Windows, macOS, and Linux, verify that the installation was successful, and resolve common installation issues. With Python installed, you're ready to start writing scripts, exploring libraries via `pip`, and building projects.

For frequently asked questions, see `FAQ.md`.
