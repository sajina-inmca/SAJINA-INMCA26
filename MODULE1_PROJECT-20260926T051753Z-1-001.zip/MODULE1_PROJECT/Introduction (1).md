# Introduction

## About Python

Python is a high-level, general-purpose programming language known for its simple, readable syntax and large ecosystem of libraries. It is widely used in web development, data science, automation, artificial intelligence, scripting, and education.

This document explains how to install Python on your computer, verify that the installation was successful, and troubleshoot common problems.

## Why Install Python?

- **Ease of learning** — Clean, English-like syntax makes it beginner-friendly.
- **Versatility** — Used for web apps, data analysis, machine learning, automation scripts, and more.
- **Large community** — Extensive documentation, tutorials, and third-party packages (via `pip`).
- **Cross-platform** — Runs on Windows, macOS, and Linux.

## Software Requirements

Before installing Python, make sure your system meets the following requirements:

| Requirement | Details |
|---|---|
| Operating System | Windows 10/11, macOS 11+, or a modern Linux distribution (Ubuntu 20.04+, Fedora, etc.) |
| Disk Space | At least 100 MB free (more if you plan to install additional packages) |
| RAM | 2 GB minimum (4 GB or more recommended) |
| Internet Connection | Required to download the installer and packages |
| Administrator/Root Access | Recommended, to allow Python to be added to the system PATH |

## What You'll Need

1. A web browser to download the installer from [python.org](https://www.python.org/downloads/).
2. Administrator (Windows/macOS) or sudo (Linux) privileges.
3. A terminal or command prompt to verify the installation.

Continue to `Installation.md` for step-by-step installation instructions.
